export class Restaurant {
    restaurantId:string;
    restaurantName: string;
    restaurantCategory: string;
    restaurantLocation:string;
    restaurantImage:string;
    constructor(){
    this.restaurantId='';
    this.restaurantName='';
    this.restaurantCategory='';
    this.restaurantLocation='';
    this.restaurantImage='';
    }
}
