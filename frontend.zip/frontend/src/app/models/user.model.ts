export class User {
    userId: number
    fname: string
    lname: string
    email: string
    password: string
    address: string
    mobile: string
    role: string;
    constructor(){
        this.userId=0;
        this.fname=' ';
        this.lname=' ';
        this.email=' ';
        this.password=' ';
        this.address=' ';
        this.mobile=' ';
        this.role=' ';
    }
    


}
