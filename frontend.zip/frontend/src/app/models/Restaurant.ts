export class Restaurant{
    restaurantId?: string;
    restaurantName?: string;
    restaurantCategory?: string;
    restaurantLocation?: string;
    restaurantImage?: string;
    restaurantStatus?: string;

}