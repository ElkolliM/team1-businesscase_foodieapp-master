export class Dish {
    
       
        dishId:string
        dishName: string
        dishType:string
        dishDetails:string
        dishPrice: number
        dishImage: string;
        constructor(){
            this.dishId='';
            this.dishDetails='';
            this.dishType=''
            this.dishName='';
            this.dishPrice=0;
            this.dishImage='';
        }


}
