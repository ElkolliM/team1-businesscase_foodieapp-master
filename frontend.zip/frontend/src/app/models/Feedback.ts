export class Feedback {
feedbackId:Number;
restaurantId:String;
title: String;
description:String;
rating:Number;
}