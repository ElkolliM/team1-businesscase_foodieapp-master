import { Restaurant } from './restaurant.model';

describe('Restaurant', () => {
  it('should create an instance', () => {
    expect(new Restaurant()).toBeTruthy();
  });
});
