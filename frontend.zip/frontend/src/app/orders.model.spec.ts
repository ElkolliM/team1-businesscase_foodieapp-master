import { Orders } from './orders.model';

describe('Orders', () => {
  it('should create an instance', () => {
    expect(new Orders()).toBeTruthy();
  });
});
